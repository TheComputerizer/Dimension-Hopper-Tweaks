package com.TheComputerizer.DimensionalHopperFinalBoss.util.interfaces;

public interface IHasModel {
    public void registerModels();
}